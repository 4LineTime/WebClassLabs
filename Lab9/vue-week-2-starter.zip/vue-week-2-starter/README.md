# Week 2 Vue.js starter code  

* v-for 
* forms - checkboxes
* forms - select 
* forms - radio buttons
* .trim
* .number
* validation
* more computed properties
